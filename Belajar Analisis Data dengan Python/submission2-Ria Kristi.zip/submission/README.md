# Bike Sharing Dashboard ✨

## Setup environment
```
cd submission
pipenv install
pipenv shell
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel
```

## Run steamlit app
```
cd dashboard
streamlit run dashboard.py
```
